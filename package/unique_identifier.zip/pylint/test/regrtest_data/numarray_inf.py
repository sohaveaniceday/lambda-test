"""#3216"""

import numarray as na
import numarray.random_array as nar
IM16 = nar.randint(0, 256, 300).astype(na.UInt8)
