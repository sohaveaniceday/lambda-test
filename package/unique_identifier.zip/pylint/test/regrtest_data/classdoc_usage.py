"""ds"""

__revision__ = None

class SomeClass(object):
    """cds"""
    doc = __doc__

    def __init__(self):
        """only to make pylint happier"""

    def please(self):
        """public method 1/2"""

    def besilent(self):
        """public method 2/2"""
